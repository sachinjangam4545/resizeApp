import React, { Component } from 'react';
import { connect } from 'react-redux';
import { createNewBook } from './actions/index';
import './App.css';


class EditBook extends Component {

    constructor(props) {
        super(props);
        this.state = {
            name: '',
            count: '',
            description: '',
            author: ''
        }
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick(event) {
        let newBook =
        {
            bookName: this.state.name,
            bookDescription: this.state.description,
            count: this.state.count,
            author: this.state.author
        }
        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }
        fetch('http://localhost:2000/products/create', {
            method: 'post',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newBook),
        }).then(function (response) {
        });
        let libraryItems = [];
        libraryItems = this.props.items;
        libraryItems.push(newBook);
        this.props.createNewBook(libraryItems)
    }
    bookNameChange(e) {
        this.setState({ name: e.target.value })
    }
    bookDescriptionChange(e) {
        this.setState({ description: e.target.value })
    }
    bookCountChange(e) {
        this.setState({ count: e.target.value })
    }
    bookAuthorChange(e) {
        this.setState({ author: e.target.value })
    }
    render() {
        console.log('edit items', this.props.editBooks)
        return (
            <div>
                <form >
                    <div class="container">
                        <h1>Add New Book</h1>
                        <hr />

                        <label for="bookName"><b>Book Name</b></label>
                        <input type="text" placeholder="Enter Book Name" name="bookName" onChange={(e) => this.bookNameChange(e)} value={this.state.name} />

                        <label for="bookDescription"><b>Book Description</b></label>
                        <input type="text" placeholder="Book Description" name="bookDescription" onChange={(e) => this.bookDescriptionChange(e)} value={this.state.description} />

                        <label for="count"><b>Number of books</b></label>
                        <input type="text" placeholder="Number of books.." name="count" onChange={(e) => this.bookCountChange(e)} value={this.state.count} />
                        <hr />
                        <label for="author"><b>Author</b></label>
                        <input type="text" placeholder="Author Name" name="count" onChange={(e) => this.bookAuthorChange(e)} value={this.state.author} />

                        <button type="button" class="addEditBtn" onClick={this.handleClick}>Edit Book</button>
                    </div>
                </form>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        items: state.bookStore.libraryItems,
        editBooks: state.bookStore.editBook
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        createNewBook: (obj) => dispatch(createNewBook(obj))
    };
};

//export default NewBook;
export default connect(mapStateToProps, mapDispatchToProps)(EditBook);
