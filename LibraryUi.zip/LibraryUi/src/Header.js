import React, { Component } from 'react';
import './App.css';
import {main} from './ContainerQuery'
import './containerQery.css'
import ResizeObserver from '@rb/resize-observer';

class Header extends Component {
  
  addBook(){
   // window.location.href = '/addNewBook'
   console.log('add book',document.getElementById('header'))
  // main();
  }
  render() {
    return (
      <div id="header" data-demo-root data-observe-resizes>
      <ResizeObserver
        onResize={({ width, height }) => {
          main();
        }}
      />
      <div className="header">
        <h1>Book Library System</h1>
        <button className="btnLib editLib" type="button" onClick={()=>this.addBook()}>Add New Book</button>
    </div>
    </div>
    );
  }
}

export default Header;
