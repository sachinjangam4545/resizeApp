import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux'
import { createStore,applyMiddleware  } from 'redux'
import thunk from 'redux-thunk';
import rootReducer from './reducers'
import './index.css';
// import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
// import 'alertifyjs/build/alertify.min.js';
// import 'alertifyjs/build/css/alertify.min.css';
// import 'alertifyjs/build/css/themes/default.min.css';
// import 'alertifyjs/build/css/themes/bootstrap.min.css';
import App from './App';
//import registerServiceWorker from './registerServiceWorker';


function configureStore(initialState) {
    return createStore(
        rootReducer,
        initialState,
        applyMiddleware(thunk)
    );
}

const store = configureStore();

ReactDOM.render(
    <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root')
);
//registerServiceWorker();
