import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import NewBook from './NewBook';
import Dashboard from './Dashboard.js';


class App extends Component {
  render() {
    return (

      <Router>
        <div>
        <Route path='/dashboard' component={Dashboard} />
        <Route path='/addNewBook' component={NewBook} />
        </div>
      </Router>
    );
  }
}

export default App;
