import axios from 'axios';
export const CREATE_NEW_BOOK = 'CREATE_NEW_BOOK'
export const STORE_LIBRARY ='STORE_LIBRARY';
export const EDIT_BOOK = 'EDIT_BOOK';

export function createNewBook(object) {
    return dispatch => {
      return new Promise(resolve => {
        dispatch({
          type: CREATE_NEW_BOOK,
          data: object,
        });
        resolve();
      });
    };
  }

export function getLibraryBooks(object){
    return dispatch => {
        return new Promise(resolve => {
          dispatch({
            type: STORE_LIBRARY,
            data: object,
          });
          resolve();
        });
      };
}

export function editBook(object){
    console.log('edit item',object)
    return dispatch => {
        return new Promise(resolve => {
          dispatch({
            type: EDIT_BOOK,
            data: object,
          });
          resolve(true);
        });
      };
}