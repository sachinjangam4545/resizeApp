import {
    CREATE_NEW_BOOK,
    STORE_LIBRARY,
    EDIT_BOOK
  } from '../actions/index';

  const initialState = {
    discount: '',
    codResponse: '',
    loyaltyCardData: '',
    libraryItems:[],
    editBook:{}
  };

  const BookStoreReducer = (state = initialState, action) => {
    switch (action.type) {
      case CREATE_NEW_BOOK:
        return Object.assign({}, state, {
            libraryItems: action.data,
        });
      case STORE_LIBRARY:
      return Object.assign({}, state, {
        libraryItems: action.data,
    });
     case EDIT_BOOK:
     return Object.assign({}, state, {
        editBook: action.data,
    });
      default:
        return state;
    }
  };

  export default BookStoreReducer;