import ResizeObserver from 'resize-observer-polyfill';

var defaultBreakpoints = { SM: 384, MD: 576, LG: 768, XL: 960 };



export const  main =() => {
    console.log('new test',ResizeObserver)
    // Create a single ResizeObserver instance to handle all
    // container elements. The instance is created with a callback,
    // which is invoked as soon as an element is observed as well
    // as any time that element's size changes.

    // const ro = new ResizeObserver((entries, observer) => {
    //     for (const entry of entries) {
    //         const {left, top, width, height} = entry.contentRect;
     
    //         console.log('Element:', entry.target);
    //         console.log(`Element's size: ${ width }px x ${ height }px`);
    //         console.log(`Element's paddings: ${ top }px ; ${ left }px`);
    //     }
    // });
     
    // ro.observe(document.body);
    var ro = new ResizeObserver( (entries,observer) => {
        console.log('test',entries)
        entries.forEach(function (entry) {
            console.log('new',entry)
            // If the target has an `updateBreakpoints` property then it's
            // a <responsive-container> element.
            if (entry.target.updateBreakpoints) {
                entry.target.updateBreakpoints(entry.contentRect.width);
            } else {
                var breakpoints = entry.target.dataset.breakpoints ?
                    JSON.parse(entry.target.dataset.breakpoints) :
                    defaultBreakpoints;

                // For non-custom-elements, use the data-obsevering attribute
                // to target observed elements in CSS.
                if (entry.width === 0) {
                    entry.target.dataset.observing = false;
                } else {
                    entry.target.dataset.observing = true;
                }

                // Update the matching breakpoints on the target element.
                Object.keys(breakpoints).forEach(function (breakpoint) {
                    var minWidth = breakpoints[breakpoint];
                    if (entry.contentRect.width >= minWidth) {
                        entry.target.classList.add(breakpoint);
                    } else {
                        entry.target.classList.remove(breakpoint);
                    }
                });
            }
        });
    });

    // Observe all non-custom element containers, i.e. all elements with the
    // `data-observe-resizes` attribute. Note: custom element containers
    // are observed via the connectedCallback() lifecycle method.
   // var elements = document.querySelectorAll('[data-observe-resizes]');
    var elements = document.querySelectorAll('[data-observe-resizes]');
   // ro.observe(document.body);
    console.log('elements',elements)
    for (var element, i = 0; element = elements[i]; i++) {
        ro.observe(element);
    }

    // Monitor the DOM for changes for non-custom-element containers.
    
    

    // Initialize the <responsive-container> custom elements.
    // Note this uses ES5 syntax so it works on IE11 with the polyfills.
    function ResponsiveContainer() {
        return typeof Reflect === 'object' ?
            Reflect.construct(HTMLElement, [], ResponsiveContainer) :
            HTMLElement.call(this) || this;
    }
    ResponsiveContainer.prototype = Object.create(HTMLElement.prototype, {
        constructor: {
            value: ResponsiveContainer,
        },
        connectedCallback: {
            value: function () {
                var breakpointsAttr = this.getAttribute('breakpoints');
                this.breakpoints = breakpointsAttr ?
                    JSON.parse(breakpointsAttr) : defaultBreakpoints;

                ro.observe(this);
                this.setAttribute('observing', '');
            },
        },
        updateBreakpoints: {
            value: function (width) {
                if (width > 0) {
                    this.setAttribute('observing', '');
                } else {
                    this.removeAttribute('observing');
                }

                for (var breakpoint in this.breakpoints) {
                    var minWidth = this.breakpoints[breakpoint];
                    if (width >= minWidth) {
                        this.classList.add(breakpoint);
                    } else {
                        this.classList.remove(breakpoint);
                    }
                }
            },
        },
    });
}